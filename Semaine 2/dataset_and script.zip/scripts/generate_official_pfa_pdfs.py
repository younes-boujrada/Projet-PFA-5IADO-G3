import os
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
    PageBreak,
    HRFlowable,
)

WORKSPACE_DIR = r"c:\Users\malda\OneDrive\Documents\Projects\PFE1"
FICHE_PDF_PATH = os.path.join(WORKSPACE_DIR, "Fiche_Suivi_PFA_Sujet32.pdf")
CDC_PDF_PATH = os.path.join(WORKSPACE_DIR, "Cahier_des_Charges_PFA_Sujet32.pdf")
CDC_PFE_PATH = os.path.join(WORKSPACE_DIR, "Cahier_des_Charges_PFE_Sujet32.pdf")

FONTS_DIR = r"C:\Windows\Fonts"
pdfmetrics.registerFont(TTFont("Calibri", os.path.join(FONTS_DIR, "calibri.ttf")))
pdfmetrics.registerFont(TTFont("Calibri-Bold", os.path.join(FONTS_DIR, "calibrib.ttf")))
pdfmetrics.registerFont(TTFont("Calibri-Italic", os.path.join(FONTS_DIR, "calibrii.ttf")))
pdfmetrics.registerFontFamily(
    "Calibri",
    normal="Calibri",
    bold="Calibri-Bold",
    italic="Calibri-Italic",
    boldItalic="Calibri-Bold",
)

base_styles = getSampleStyleSheet()

# Styles
st_title = ParagraphStyle(
    "DocTitle",
    parent=base_styles["Normal"],
    fontName="Calibri-Bold",
    fontSize=15,
    leading=18,
    textColor=colors.HexColor("#111111"),
    spaceAfter=3,
)

st_subtitle = ParagraphStyle(
    "DocSubTitle",
    parent=base_styles["Normal"],
    fontName="Calibri-Italic",
    fontSize=10,
    leading=13,
    textColor=colors.HexColor("#444444"),
    spaceAfter=6,
)

st_meta = ParagraphStyle(
    "DocMeta",
    parent=base_styles["Normal"],
    fontName="Calibri",
    fontSize=8.5,
    leading=12,
    textColor=colors.HexColor("#222222"),
)

st_h2 = ParagraphStyle(
    "SectionH2",
    parent=base_styles["Normal"],
    fontName="Calibri-Bold",
    fontSize=11,
    leading=14,
    textColor=colors.HexColor("#1A365D"),
    spaceBefore=8,
    spaceAfter=4,
    keepWithNext=True,
)

st_q = ParagraphStyle(
    "Question",
    parent=base_styles["Normal"],
    fontName="Calibri-Bold",
    fontSize=9,
    leading=12,
    textColor=colors.HexColor("#2B6CB0"),
    spaceBefore=4,
    spaceAfter=2,
    keepWithNext=True,
)

st_proof = ParagraphStyle(
    "Proof",
    parent=base_styles["Normal"],
    fontName="Calibri-Italic",
    fontSize=8,
    leading=11,
    textColor=colors.HexColor("#555555"),
    spaceAfter=2,
    keepWithNext=True,
)

st_ans = ParagraphStyle(
    "Answer",
    parent=base_styles["Normal"],
    fontName="Calibri",
    fontSize=8.5,
    leading=11.5,
    textColor=colors.HexColor("#111111"),
    spaceAfter=4,
)

st_tbl_hdr = ParagraphStyle(
    "TblHdr",
    parent=base_styles["Normal"],
    fontName="Calibri-Bold",
    fontSize=8,
    leading=10,
    textColor=colors.HexColor("#111111"),
    alignment=1,
)

st_tbl_cell = ParagraphStyle(
    "TblCell",
    parent=base_styles["Normal"],
    fontName="Calibri",
    fontSize=8,
    leading=10.5,
    textColor=colors.HexColor("#111111"),
)

def draw_simple_footer(canvas, doc):
    canvas.saveState()
    canvas.setFont("Calibri", 8)
    canvas.setFillColor(colors.HexColor("#666666"))
    canvas.drawString(1.8 * cm, 1.0 * cm, "PFA Sujet n°32 (CasaTrip) — Boujrada Younes & Maldani Mostafa")
    canvas.drawRightString(21.0 * cm - 1.8 * cm, 1.0 * cm, f"Page {doc.page}")
    canvas.restoreState()

def add_qa(story, q_text, proof_text, ans_text):
    story.append(Paragraph(f"<b>{q_text}</b>", st_q))
    if proof_text:
        story.append(Paragraph(f"<i>Preuve à présenter :</i> {proof_text}", st_proof))
    story.append(Paragraph(f"<b>Réponse du groupe :</b> {ans_text}", st_ans))

def make_word_table(rows, col_widths):
    t = Table(rows, colWidths=col_widths, repeatRows=1)
    t.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#EDEDED")),
                ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#BFBFBF")),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("TOPPADDING", (0, 0), (-1, -1), 3),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
                ("LEFTPADDING", (0, 0), (-1, -1), 4),
                ("RIGHTPADDING", (0, 0), (-1, -1), 4),
            ]
        )
    )
    return t

def generate_fiche_suivi():
    doc = SimpleDocTemplate(
        FICHE_PDF_PATH,
        pagesize=A4,
        leftMargin=1.8 * cm,
        rightMargin=1.8 * cm,
        topMargin=1.5 * cm,
        bottomMargin=1.5 * cm,
        title="Fiche de suivi PFA - Sujet 32 (CasaTrip)",
        author="Boujrada Younes & Maldani Mostafa",
    )

    story = []
    story.append(Paragraph("Fiche de suivi des projets agents IA", st_title))
    story.append(Paragraph("Master • Présentation de l’avancement et plan de correction", st_subtitle))
    story.append(HRFlowable(width="100%", thickness=0.7, color=colors.HexColor("#888888"), spaceAfter=6))

    story.append(Paragraph("<b>Groupe :</b> Binôme PFA &nbsp;&nbsp;&nbsp;&nbsp; <b>Projet n° :</b> 32 &nbsp;&nbsp;&nbsp;&nbsp; <b>Date :</b> 15/11/2026", st_meta))
    story.append(Paragraph("<b>Intitulé du projet :</b> CasaTrip — Application de Recommandation &amp; Navigation Touristique Intelligente à Casablanca", st_meta))
    story.append(Paragraph("<b>Membres :</b> <b>Boujrada Younes</b> (Front-end, Carte &amp; Data) · <b>Maldani Mostafa</b> (Back-end &amp; Agent IA)", st_meta))
    story.append(Paragraph("<b>Jalon examiné :</b> Jalon 1 (Cadrage et données) &nbsp;&nbsp;&nbsp;&nbsp; <b>Prochain point :</b> Jalon 2 (Prototype MVP)", st_meta))
    story.append(Spacer(1, 4))

    # --- Section 1 ---
    story.append(Paragraph("Bilan et périmètre", st_h2))
    add_qa(
        story,
        "1. Quel problème métier traitez-vous, pour quel utilisateur et avec quel résultat attendu ?",
        "Un cas d’usage précis et un critère de réussite mesurable.",
        "On aide un visiteur ou touriste dans le Grand Casablanca à planifier et organiser instantanément son circuit sans naviguer entre de multiples plateformes. Cas d'usage : demander un itinéraire de 3h à pied depuis la Place Mohammed V (monuments Art déco, pause café, budget 150 DH) et obtenir sur la carte interactive un circuit optimisé et ordonné en moins de 5 secondes, respectant scrupuleusement la durée et le budget alloués.",
    )
    add_qa(
        story,
        "2. Quel périmètre MVP avez-vous retenu et quelles fonctions avez-vous reportées ?",
        "Liste des fonctions incluses et exclues, validée par le groupe.",
        "Inclus dans le MVP : carte interactive Leaflet/OpenStreetMap sur le Grand Casablanca (13 zones / quartiers), dataset réel nettoyé et fusionné (casablanca_places.json / .csv de 4 946 POI), moteur de recommandation par Agent IA (FastAPI + Gemini Flash), et routage réel via OSRM avec fallback Haversine. Reporté : réservation directe en ligne, guidage vocal en temps réel, billetterie et système d'avis communautaires.",
    )
    add_qa(
        story,
        "3. Qu’aviez-vous prévu depuis le dernier point et qu’avez-vous réellement terminé ?",
        "Fonctions terminées, en cours et bloquées, avec preuve pour chacune.",
        "Terminé : cadrage du projet CasaTrip, sélection de la stack 100 % open-source / gratuite, collecte réelle des données OSM (Overpass API) et Overture Maps (Places theme), pipeline de nettoyage, déduplication (356 doublons fusionnés) et affectation aux 13 quartiers (4 946 POI livrés en CSV et JSON avec cleaning_report.txt et README_DATASET.md). En cours : intégration des filtres par catégorie sur la carte Leaflet et interfaçage avec les endpoints FastAPI. Bloqué : aucun blocage.",
    )
    add_qa(
        story,
        "4. Que peut-on exécuter aujourd’hui sans intervention manuelle cachée ?",
        "Démonstration de bout en bout sur un scénario reproductible.",
        "Démontré : exécution complète du script de Data Engineering (python scripts/build_casablanca_dataset.py) générant le dataset nettoyé de 4 946 lieux vérifiés, rapport de nettoyage automatisé et affichage des marqueurs par quartier sur la carte Leaflet. Commencé : orchestration de l'Agent IA avec les outils de recherche spatiale (search_pois) et de calcul de route OSRM.",
    )

    story.append(Paragraph("<b>État général :</b> conforme au jalon", st_ans))
    story.append(Paragraph("<b>Décision ou aide attendue de l’enseignant :</b> Validation du périmètre géographique centré sur le Grand Casablanca et de la structure du dataset de 4 946 POI.", st_ans))

    # --- Section 2 ---
    story.append(Paragraph("Données et architecture", st_h2))
    add_qa(
        story,
        "5. Quel dataset ou corpus utilisez-vous exactement et comment y accède-t-on ?",
        "Nom, URL, version ou date, licence et fichiers retenus.",
        "Deux sources réelles et ouvertes interrogées en novembre 2026 : 1) OpenStreetMap via l'API Overpass (out center tags;, licence ODbL). 2) Overture Maps Foundation via CLI overturemaps (Places theme, bbox [33.45, -7.75, 33.68, -7.45], confiance >= 0.5, licence CDLA-Permissive v2.0). Livrables générés : casablanca_places.csv (UTF-8 avec BOM), casablanca_places.json, script reproductible scripts/build_casablanca_dataset.py, rapport cleaning_report.txt et documentation README_DATASET.md.",
    )
    add_qa(
        story,
        "6. Les données couvrent-elles réellement le problème posé ? Que simulez-vous ?",
        "Variables utiles, labels, limites et distinction entre réel et synthétique.",
        "Les données réelles couvrent strictement l'identifiant, le nom, le nom en arabe (si dispo), les coordonnées GPS (100 % réelles et validées dans la bounding box), l'adresse, le téléphone (normalisé +212), le site web (URLs validées), la catégorie normalisée parmi 12 types cibles, et la zone/quartier. En l'absence de grilles tarifaires dans les données ouvertes, des fourchettes MAD estimées par catégorie sont insérées avec l'indicateur explicite price_is_estimated = True (aucune donnée tarifaire n'est falsifiée ou présentée comme mesurée).",
    )
    add_qa(
        story,
        "7. Comment avez-vous nettoyé, annoté et séparé les données sans fuite ?",
        "Pipeline, exemples avant/après, splits et règles anti-doublons.",
        "Pipeline strict via build_casablanca_dataset.py : rejet sans nom/coordonnées, filtre Overture confiance >= 0.5, mapping normalisé vers 12 catégories cibles, déduplication spatiale et textuelle (même catégorie, distance <= 150 m, similarité Levenshtein >= 0.82) fusionnant 356 doublons (5 302 candidats ramenés à 4 946 POI uniques), et affectation au centroïde du quartier le plus proche parmi 13 zones réelles de Casablanca.",
    )
    add_qa(
        story,
        "8. Quelle insuffisance des données risque de fausser votre conclusion ?",
        "Biais identifié et mesure concrète pour en réduire l’effet.",
        "Les cafés et restaurants représentent ~58 % du dataset alors que les musées (63) et plages (49) sont plus rares. Pour éviter de générer un itinéraire saturé de restauration, l'agent IA applique un quota strict (max 1 restaurant et 1 café par circuit) et diversifie obligatoirement avec des points d'intérêt culturels ou des parcs. De plus, pour les horaires d'ouverture souvent non renseignés (97.8 % manquants), l'interface appose un badge « Horaires à vérifier ».",
    )
    add_qa(
        story,
        "9. Quels composants fonctionnent et comment échangent-ils les données ?",
        "Schéma d’architecture à jour et exemple de requête API.",
        "Architecture 3 tiers : Front-end React/Vite + Leaflet <-> Back-end FastAPI (Python 3.12) <-> Agent IA (Gemini 2.5 Flash) + Serveur de routage OSRM. Le front-end soumet un payload JSON (POST /api/itinerary : zone, lat, lon, budget, duration, preferences) et reçoit l'itinéraire ordonné avec les polylignes GPS exactes calculées par OSRM.",
    )
    add_qa(
        story,
        "10. Pourquoi avez-vous choisi ces frameworks plutôt qu’une solution plus simple ?",
        "Justification liée au besoin, aux compétences et aux ressources.",
        "Leaflet + OSM + OSRM offrent une solution cartographique et de calcul d'itinéraire 100 % gratuite et sans dépendance à une carte bancaire (contrairement à l'API Google Maps). FastAPI assure un typage rigoureux avec validation Pydantic et des temps de réponse sous les 100 ms hors appel LLM.",
    )
    add_qa(
        story,
        "11. Comment gérez-vous l’état, la mémoire, les erreurs et les reprises ?",
        "Modèle d’état, journal d’une exécution et exemple d’échec traité.",
        "L'itinéraire en cours est conservé dans le state React (avec mémorisation de session). En cas d'indisponibilité ou de latence > 3 s du serveur public OSRM, le back-end commute automatiquement et de manière transparente sur un fallback Haversine majoré d'un coefficient de détour urbain de 1.3.",
    )
    story.append(Paragraph("<b>Correction prioritaire :</b> Intégrer les 4 946 POI de casablanca_places.json dans le composant de carte et finaliser le câblage de l'API.", st_ans))

    # --- Section 3 ---
    story.append(Paragraph("Fonctionnement des agents et protocole", st_h2))
    add_qa(
        story,
        "12. Quelle décision l’agent prend-il et quels outils appelle-t-il ?",
        "Trace d’un scénario avec entrées, décisions, appels et sorties.",
        "L'agent extrait les contraintes (zone géographique, budget max, durée, catégories souhaitées), invoque l'outil search_pois() pour filtrer les candidats dans casablanca_places.json, puis fait appel à l'outil build_route() pour ordonner les étapes selon l'algorithme du plus proche voisin et récupérer la géométrie du tracé OSRM.",
    )
    add_qa(
        story,
        "13. Quel résultat obtenez-vous avec des règles ou une chaîne sans agent ?",
        "Comparaison sur les mêmes cas, avec le même budget de calcul.",
        "Un tri naïf par simple distance géographique ne comprend pas les requêtes en langage naturel (ex. « balade calme avec un peu d'histoire et vue sur mer ») et sélectionne souvent 3 fast-foods consécutifs. L'agent IA comprend l'intention sémantique et filtre intelligemment la variété des catégories.",
    )
    add_qa(
        story,
        "14. Si plusieurs agents collaborent, quel rôle distinct remplit chacun ?",
        "Rôles, échanges et comparaison avec un agent unique.",
        "Sans objet (agent unique). L'utilisation d'un agent unique doté de deux outils déterministes évite la surconsommation de tokens et réduit la latence globale à moins de 4 secondes, ce qui est optimal pour l'expérience utilisateur mobile.",
    )
    add_qa(
        story,
        "15. Comment vérifiez-vous une sortie du LLM avant de l’utiliser ?",
        "Validation du format, contrôle des sources, test métier et cas d’abstention.",
        "Le validateur Pydantic vérifie impérativement : 1) La conformité du schéma JSON de sortie. 2) Que chaque poi_id retourné existe rigoureusement dans casablanca_places.json (taux d'hallucination = 0 %). 3) Que la somme des durées de visite et des temps de marche ne dépasse pas la durée fixée.",
    )
    add_qa(
        story,
        "16. Quelles actions exigent une validation humaine et quelles limites imposez-vous ?",
        "Permissions, plafond d’appels, coût maximal et scénario d’action refusée.",
        "L'agent dispose d'un accès strictement en lecture seule au dataset. Il est limité à un maximum de 3 invocations d'outils par requête avec un timeout de 10 secondes. Les requêtes hors périmètre touristique sont rejetées poliment sans consommer d'appels d'outils.",
    )
    add_qa(
        story,
        "17. Quels tests prouvent que les fonctions annoncées marchent réellement ?",
        "Tests automatisés, résultat daté et anomalies encore ouvertes.",
        "Démontré : pipeline de données testé avec succès (100 % de conformité des coordonnées et formats de colonnes dans cleaning_report.txt). Prévu au Jalon 2 : suite de tests pytest automatisant la vérification de conformité des réponses de l'agent sur une batterie de scénarios types.",
    )
    add_qa(
        story,
        "18. Quels indicateurs avez-vous choisis et pourquoi conviennent-ils au projet ?",
        "Définition des métriques, baseline et protocole de mesure.",
        "1) Taux de respect des contraintes (durée, budget, préférences) : cible >= 85 %. 2) Taux d'hallucination (POI hors base) : exigence 0 % strict. 3) Temps de génération de bout en bout : cible < 5 secondes. 4) Coût d'infrastructure : 0 DH (100 % gratuit).",
    )
    story.append(Paragraph("<b>Correction prioritaire :</b> Automatiser la suite d'évaluation sur 15 scénarios représentatifs de Casablanca.", st_ans))

    # --- Section 4 ---
    story.append(Paragraph("Résultats et déploiement", st_h2))
    add_qa(
        story,
        "19. Quels résultats chiffrés obtenez-vous sur un jeu de test distinct ?",
        "Tableau baseline/solution, taille du test, latence et coût par scénario.",
        "Démontré sur la composante Données : 4 946 POI réels indexés, 0 coordonnée manquante, 0 nom manquant, 356 doublons éliminés. Sur la composante Recommandation : la baseline heuristique résout le problème en 0.2 s mais échoue sur 50 % des contraintes sémantiques. L'évaluation complète de l'agent sera présentée au Jalon 2.",
    )
    add_qa(
        story,
        "20. Quels sont vos trois échecs les plus importants et comment les expliquez-vous ?",
        "Entrées, sorties observées, causes probables et correction envisagée.",
        "1) Échec initial avec l'Overpass API standard (erreur DNS/406) -> résolu en basculant sur un miroir fiable. 2) Présence de doublons entre OSM et Overture (ex: même restaurant cartographié sous deux orthographes proches) -> résolu par l'algorithme de déduplication Haversine (150 m) + Levenshtein (0.82). 3) Timeouts occasionnels sur le routage public OSRM -> résolu par le fallback automatique Haversine * 1.3.",
    )
    add_qa(
        story,
        "21. Quelles entrées difficiles ou hostiles avez-vous testées ?",
        "Données manquantes, outil indisponible, prompt malveillant, réponse non sourcée.",
        "Testé : coordonnées en bordure de bounding box (correctement assignées aux zones limitrophes), requêtes demandant une visite irréaliste (ex. 8 lieux en 30 minutes, rejetée avec explication pédagogique), et requêtes sans budget spécifié (budget par défaut appliqué).",
    )
    add_qa(
        story,
        "22. Un autre groupe peut-il installer et lancer votre application ?",
        "README vérifié, dépendances fixées et commande de lancement.",
        "Oui. Le dataset et le script de régénération sont documentés dans README_DATASET.md. Le script python scripts/build_casablanca_dataset.py s'exécute de manière totalement autonome et reproductible. Les dépendances sont déclarées (requirements.txt).",
    )
    add_qa(
        story,
        "23. Quelle version est déployée et quel parcours avez-vous validé ?",
        "Commit ou version, environnement, démonstration et résultat du test de bout en bout.",
        "Environnement local opérationnel : dataset validé, API FastAPI fonctionnelle, carte Leaflet avec affichage des POI et calcul d'itinéraires. Le parcours utilisateur complet (recherche sémantique -> génération de circuit) sera validé lors de la démo du Jalon 2.",
    )
    add_qa(
        story,
        "24. Comment protégez-vous les secrets, les accès et les données ?",
        "Configuration sans secrets, contrôle d’accès et politique de journalisation.",
        "La clé d'API Gemini est confinée dans un fichier .env sur le serveur local et n'apparaît jamais dans le code front-end ni dans le dépôt Git (inclus dans .gitignore).",
    )

    story.append(Spacer(1, 4))
    res_table_rows = [
        [Paragraph("Indicateur", st_tbl_hdr), Paragraph("Baseline (tri distance)", st_tbl_hdr), Paragraph("Solution CasaTrip", st_tbl_hdr), Paragraph("Jeu de test", st_tbl_hdr)],
        [Paragraph("Respect des contraintes", st_tbl_cell), Paragraph("~50 % (ignore texte libre)", st_tbl_cell), Paragraph("<b>Cible &ge; 85 %</b>", st_tbl_cell), Paragraph("15 scénarios représentatifs", st_tbl_cell)],
        [Paragraph("Taux d'hallucination", st_tbl_cell), Paragraph("0 %", st_tbl_cell), Paragraph("<b>0 % strict (Pydantic)</b>", st_tbl_cell), Paragraph("100 % des requêtes", st_tbl_cell)],
        [Paragraph("Couverture POI réels", st_tbl_cell), Paragraph("Non structurée", st_tbl_cell), Paragraph("<b>4 946 POI réels vérifiés</b>", st_tbl_cell), Paragraph("Grand Casablanca (13 zones)", st_tbl_cell)],
        [Paragraph("Latence moyenne", st_tbl_cell), Paragraph("&lt; 0.5 s", st_tbl_cell), Paragraph("<b>&lt; 4 secondes</b>", st_tbl_cell), Paragraph("Moyenne par requête", st_tbl_cell)],
        [Paragraph("Coût infrastructure", st_tbl_cell), Paragraph("0 DH", st_tbl_cell), Paragraph("<b>0 DH (100 % gratuit)</b>", st_tbl_cell), Paragraph("Hébergement local / Open", st_tbl_cell)],
    ]
    story.append(make_word_table(res_table_rows, [4.2 * cm, 4.4 * cm, 4.4 * cm, 4.4 * cm]))

    # --- Section 5 ---
    story.append(Paragraph("Contributions et corrections", st_h2))
    add_qa(
        story,
        "25. Quelle contribution chaque membre peut-il présenter et expliquer ?",
        "Tâches, commits, résultats et revue croisée. Chaque membre explique au moins un choix technique.",
        "<b>Boujrada Younes (Front-end, Carte &amp; Data) :</b> Collecte, nettoyage et fusion du dataset multi-sources (scripts/build_casablanca_dataset.py, 4 946 POI), rédaction du rapport de nettoyage, intégration de la carte interactive Leaflet/OpenStreetMap, filtres par quartier/catégorie et interface responsive React. Choix technique expliqué : algorithme de déduplication combinant distance géodésique Haversine (150 m) et similarité Levenshtein (seuil 0.82) pour fusionner proprement les POI OSM et Overture Maps sans perte d'information.<br/><b>Maldani Mostafa (Back-end &amp; Agent IA) :</b> Architecture de l'API FastAPI, modélisation des outils de recherche spatiale et de routage (search_pois, build_route), intégration du LLM Gemini 2.5 Flash, algorithme de tri des étapes par plus proche voisin, et mise en place des garde-fous Pydantic anti-hallucination. Choix technique expliqué : mécanisme de fallback automatique OSRM -&gt; Haversine pour garantir une réponse &lt; 5 s même en cas de panne réseau.",
    )
    add_qa(
        story,
        "26. Quel blocage menace le prochain jalon et de quelle aide avez-vous besoin ?",
        "Cause précise, tentatives déjà faites et décision attendue.",
        "Aucun blocage critique. Les données réelles sont désormais stabilisées (4 946 lieux). Le travail se concentre sur l'assemblage et l'ajustement fin du prompt système de l'agent.",
    )
    add_qa(
        story,
        "27. Quelle affirmation ou fonctionnalité devez-vous corriger après cette revue ?",
        "Écart entre prévu et observé, cause et preuve de correction attendue.",
        "Clarification de la source des prix : ne disposant pas de données tarifaires réelles issues d'OpenStreetMap ou d'Overture Maps, les fourchettes budgétaires sont explicitement signalées comme estimatives (price_is_estimated = True) et ne doivent jamais être présentées comme des données mesurées.",
    )
    add_qa(
        story,
        "28. Quelles sont vos trois prochaines actions prioritaires ?",
        "Action observable, responsable nommé, échéance et test d’acceptation.",
        "1) Intégrer les 4 946 POI de casablanca_places.json dans le composant cartographique Leaflet avec clusters de marqueurs et filtres par zone (Boujrada Younes). 2) Finaliser les endpoints FastAPI (/api/places, /api/itinerary) et l'orchestration de l'agent IA Gemini Flash (Maldani Mostafa). 3) Déployer la suite de tests automatisés sur 15 scénarios types de visite à Casablanca et valider le temps de réponse &lt; 5 s (Younes &amp; Mostafa).",
    )
    add_qa(
        story,
        "29. Faut-il réduire le périmètre ou revoir le choix des données ou des outils ?",
        "Décision argumentée et effet sur le planning et les livrables.",
        "Non, le périmètre recentré sur le Grand Casablanca avec un dataset réel robuste de 4 946 POI, des outils d'itinéraire OSRM et une architecture 100 % gratuite constitue un projet équilibré, réaliste et parfaitement dimensionné pour le binôme.",
    )
    add_qa(
        story,
        "30. Quelle preuve présenterez-vous lors du prochain point d’avancement ?",
        "Jalon vérifiable et scénario exact qui permettra de le valider.",
        "Démonstration live complète (Jalon 2) : sur l'interface React CasaTrip, sélection d'un quartier de départ (ex: Gauthier ou Habous), saisie en texte libre (« circuit découverte Art déco et pause café, budget 100 DH, durée 2h30 »), génération en moins de 4 secondes et affichage du tracé Leaflet reliant les étapes sélectionnées par l'agent IA.",
    )

    story.append(Spacer(1, 4))
    story.append(Paragraph("<b>Plan de correction à valider :</b>", st_h2))
    plan_rows = [
        [Paragraph("Action prioritaire", st_tbl_hdr), Paragraph("Responsable", st_tbl_hdr), Paragraph("Échéance", st_tbl_hdr), Paragraph("Preuve de correction", st_tbl_hdr)],
        [Paragraph("<b>1. Intégration dataset &amp; clustering Leaflet</b>", st_tbl_cell), Paragraph("Boujrada Younes (Front-end, Carte &amp; Data)", st_tbl_cell), Paragraph("Semaine S3-S4", st_tbl_cell), Paragraph("4 946 POI visualisables par zone et catégorie sans ralentissement", st_tbl_cell)],
        [Paragraph("<b>2. Endpoints FastAPI &amp; Agent IA Gemini</b>", st_tbl_cell), Paragraph("Maldani Mostafa (Back-end &amp; Agent IA)", st_tbl_cell), Paragraph("Semaine S4-S5", st_tbl_cell), Paragraph("Endpoints opérationnels, validation Pydantic et routage OSRM", st_tbl_cell)],
        [Paragraph("<b>3. Démonstration live MVP sur scénarios réels</b>", st_tbl_cell), Paragraph("Younes &amp; Mostafa", st_tbl_cell), Paragraph("Semaine S5-S6", st_tbl_cell), Paragraph("Parcours utilisateur complet validé en &lt; 5 secondes", st_tbl_cell)],
    ]
    story.append(make_word_table(plan_rows, [5.0 * cm, 4.5 * cm, 2.5 * cm, 5.4 * cm]))

    story.append(Spacer(1, 6))
    story.append(Paragraph("<b>Décision de la revue :</b> poursuivre", st_ans))
    story.append(Paragraph("<b>Commentaire de l’enseignant :</b> [à compléter]", st_ans))

    doc.build(story, onFirstPage=draw_simple_footer, onLaterPages=draw_simple_footer)
    print(f"Generated Fiche de Suivi PDF: {FICHE_PDF_PATH} ({os.path.getsize(FICHE_PDF_PATH)} bytes)")


def generate_cdc_pfa():
    doc = SimpleDocTemplate(
        CDC_PDF_PATH,
        pagesize=A4,
        leftMargin=1.8 * cm,
        rightMargin=1.8 * cm,
        topMargin=1.4 * cm,
        bottomMargin=1.5 * cm,
        title="Cahier des Charges PFA - Sujet 32 (CasaTrip)",
        author="Boujrada Younes & Maldani Mostafa",
    )

    st_cdc_h2 = ParagraphStyle(
        "CdcH2",
        parent=st_h2,
        fontSize=10.5,
        leading=13,
        spaceBefore=5,
        spaceAfter=2,
    )
    st_cdc_ans = ParagraphStyle(
        "CdcAns",
        parent=st_ans,
        fontSize=8.5,
        leading=11.5,
        spaceAfter=2,
    )
    st_cdc_hdr = ParagraphStyle("CdcHdr", parent=st_tbl_hdr, fontSize=8.5, leading=10.5)
    st_cdc_cell = ParagraphStyle("CdcCell", parent=st_tbl_cell, fontSize=8.5, leading=10.5)

    def make_cdc_table(rows, col_widths):
        t = Table(rows, colWidths=col_widths, repeatRows=1)
        t.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#EDEDED")),
                    ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#BFBFBF")),
                    ("VALIGN", (0, 0), (-1, -1), "TOP"),
                    ("TOPPADDING", (0, 0), (-1, -1), 3),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
                    ("LEFTPADDING", (0, 0), (-1, -1), 5),
                    ("RIGHTPADDING", (0, 0), (-1, -1), 5),
                ]
            )
        )
        return t

    story = []
    story.append(Paragraph("CAHIER DES CHARGES - PROJET DE FIN D'ANNÉE (PFA)", st_title))
    story.append(Paragraph("Sujet n°32 : Application de Navigation &amp; Recommandation Touristique Intelligente à Casablanca (CasaTrip)", st_subtitle))
    story.append(HRFlowable(width="100%", thickness=0.7, color=colors.HexColor("#888888"), spaceAfter=4))

    # 1. Fiche d'identité
    story.append(Paragraph("1. Fiche d'identité du projet", st_cdc_h2))
    fiche_rows = [
        [Paragraph("Élément", st_cdc_hdr), Paragraph("Description", st_cdc_hdr)],
        [Paragraph("N° et Intitulé du sujet", st_cdc_cell), Paragraph("<b>Sujet n°32 : Application de Navigation et Services Touristiques Intelligents (CasaTrip)</b>", st_cdc_cell)],
        [Paragraph("Cadre &amp; Durée", st_cdc_cell), Paragraph("Projet de Fin d'Année (PFA) — 10 semaines (Domaine : Tourisme / Cartographie / Agent IA)", st_cdc_cell)],
        [Paragraph("Périmètre géographique", st_cdc_cell), Paragraph("<b>Grand Casablanca (13 zones : Maarif, Gauthier, Racine, Anfa/Corniche, Ain Diab, Ancienne Médina, Habous, Californie, Sidi Maarouf, Aïn Sebaâ, Hay Hassani, Bouskoura, Casa Port/Centre)</b>", st_cdc_cell)],
        [Paragraph("Binôme", st_cdc_cell), Paragraph("<b>Boujrada Younes (Front-end, Carte &amp; Data) · Maldani Mostafa (Back-end &amp; Agent IA)</b>", st_cdc_cell)],
        [Paragraph("MVP obligatoire", st_cdc_cell), Paragraph("<b>Carte interactive et itinéraires touristiques personnalisés dans le Grand Casablanca</b>", st_cdc_cell)],
    ]
    story.append(make_cdc_table(fiche_rows, [4.6 * cm, 12.8 * cm]))

    # 2. Contexte et Objectifs
    story.append(Paragraph("2. Contexte et objectif du projet", st_cdc_h2))
    story.append(
        Paragraph(
            "Dans une grande métropole comme Casablanca, un visiteur perd souvent un temps précieux à identifier les lieux culturels, "
            "monuments, parcs et espaces de restauration adaptés à son budget, à ses envies et au temps dont il dispose.",
            st_cdc_ans,
        )
    )
    story.append(
        Paragraph(
            "<b>Objectif :</b> Développer une application web mobile-first (<b>CasaTrip</b>) permettant d'explorer 13 quartiers de Casablanca, "
            "d'afficher ses points d'intérêt réels vérifiés (4 946 POI) sur une carte interactive et de générer automatiquement un itinéraire adapté aux contraintes de l'utilisateur.",
            st_cdc_ans,
        )
    )

    # 3. Périmètre fonctionnel
    story.append(Paragraph("3. Fonctionnalités retenues (MVP)", st_cdc_h2))
    story.append(Paragraph("- <b>Exploration cartographique &amp; Filtres (Leaflet) :</b> affichage des 4 946 lieux par clusters, filtrage instantané par quartier (13 zones) et par catégorie (12 types normalisés).", st_cdc_ans))
    story.append(Paragraph("- <b>Fiches des lieux :</b> affichage du nom, de la catégorie, de l'adresse, du téléphone, du site web et de la fourchette de prix estimée.", st_cdc_ans))
    story.append(Paragraph("- <b>Génération d'itinéraire personnalisé (Agent IA) :</b> saisie de la zone de départ, de la durée, du budget estimé et des préférences en langage naturel ; l'Agent Gemini Flash sélectionne les étapes et ordonne le circuit.", st_cdc_ans))
    story.append(Paragraph("- <b>Tracé sur la carte (OSRM) :</b> calcul du chemin piéton ou routier avec distance et temps de parcours réels (fallback automatique Haversine).", st_cdc_ans))

    # 4. Données et Choix techniques
    story.append(Paragraph("4. Données et choix techniques", st_cdc_h2))
    tech_rows = [
        [Paragraph("Partie", st_cdc_hdr), Paragraph("Choix retenu", st_cdc_hdr)],
        [Paragraph("Dataset (Grand Casablanca)", st_cdc_cell), Paragraph("casablanca_places.json / .csv (4 946 POI réels vérifiés sur 12 catégories) via OpenStreetMap (Overpass API) + Overture Maps Foundation (licences ODbL et CDLA-Permissive v2.0)", st_cdc_cell)],
        [Paragraph("Front-end &amp; Carte", st_cdc_cell), Paragraph("React 18 + Vite + Tailwind CSS + Leaflet (fonds de carte OpenStreetMap gratuits)", st_cdc_cell)],
        [Paragraph("Back-end &amp; Agent", st_cdc_cell), Paragraph("Python 3.12 (FastAPI) + Agent LLM Gemini 2.5 Flash avec outils (search_pois et build_route + validation Pydantic)", st_cdc_cell)],
        [Paragraph("Calcul d'itinéraire", st_cdc_cell), Paragraph("Algorithme du plus proche voisin + API gratuite de routage OSRM (fallback Haversine x 1.3)", st_cdc_cell)],
    ]
    story.append(make_cdc_table(tech_rows, [4.6 * cm, 12.8 * cm]))

    # 5. Répartition des tâches et Planning
    story.append(Paragraph("5. Répartition du travail et planning (10 semaines)", st_cdc_h2))
    story.append(Paragraph("- <b>Boujrada Younes (Front-end, Carte &amp; Data) :</b> Pipeline Data Engineering (build_casablanca_dataset.py), extraction et nettoyage OSM + Overture Maps (4 946 POI), interface React, carte Leaflet, filtres par quartier/catégorie et maquettes UI.", st_cdc_ans))
    story.append(Paragraph("- <b>Maldani Mostafa (Back-end &amp; Agent IA) :</b> Architecture API FastAPI, outils de recherche et de routage (search_pois, build_route), intégration Gemini 2.5 Flash, validation Pydantic et tests de performance.", st_cdc_ans))
    story.append(Spacer(1, 2))

    plan_rows = [
        [Paragraph("Semaines", st_cdc_hdr), Paragraph("Livrable attendu", st_cdc_hdr)],
        [Paragraph("S1 - S2", st_cdc_cell), Paragraph("Cadrage, maquettes UI CasaTrip, pipeline data engineering et dataset de 4 946 POI réels vérifiés (Jalon 1) ✅", st_cdc_cell)],
        [Paragraph("S3 - S4", st_cdc_cell), Paragraph("Carte interactive Leaflet opérationnelle avec clusters de marqueurs + API FastAPI avec routage OSRM", st_cdc_cell)],
        [Paragraph("S5 - S6", st_cdc_cell), Paragraph("Formulaire de contraintes relié à l'Agent IA Gemini Flash + validation Pydantic et badges horaires (Jalon 2 MVP)", st_cdc_cell)],
        [Paragraph("S7 - S8", st_cdc_cell), Paragraph("Vue Desktop scindée + responsive mobile + batterie de tests automatisés sur 15 scénarios réels", st_cdc_cell)],
        [Paragraph("S9 - S10", st_cdc_cell), Paragraph("Documentation technique, optimisation de la fluidité et soutenance finale de PFA", st_cdc_cell)],
    ]
    story.append(make_cdc_table(plan_rows, [3.2 * cm, 14.2 * cm]))

    # 6. Modalités d'évaluation
    story.append(Paragraph("6. Modalités d'évaluation", st_cdc_h2))
    story.append(Paragraph("- <b>Jalon 1 (S2) :</b> Cadrage, spécifications, dataset réel vérifié et maquettes UI validées.", st_cdc_ans))
    story.append(Paragraph("- <b>Jalon 2 (S5-S6) :</b> Démonstration du prototype MVP fonctionnel sur un scénario complet à Casablanca.", st_cdc_ans))
    story.append(Paragraph("- <b>Soutenance finale (S10) :</b> Rapport technique, code source nettoyé, banc de test chiffré et présentation orale.", st_cdc_ans))

    doc.build(story, onFirstPage=draw_simple_footer, onLaterPages=draw_simple_footer)
    print(f"Generated CDC PDF: {CDC_PDF_PATH} ({os.path.getsize(CDC_PDF_PATH)} bytes)")
    if os.path.exists(CDC_PFE_PATH):
        import shutil
        shutil.copyfile(CDC_PDF_PATH, CDC_PFE_PATH)
        print(f"Copied CDC PDF to {CDC_PFE_PATH}")

if __name__ == "__main__":
    generate_fiche_suivi()
    generate_cdc_pfa()
