import os
import sys
import json
import math
import re
import unicodedata
import difflib
import csv
from collections import Counter
import requests

# -----------------------------------------------------------------------------
# CONFIGURATION & BOUNDING BOX
# -----------------------------------------------------------------------------
# Greater Casablanca: south 33.45, west -7.75, north 33.68, east -7.45
BBOX_SOUTH = 33.45
BBOX_WEST = -7.75
BBOX_NORTH = 33.68
BBOX_EAST = -7.45

PROJ_DIR = r"c:\Users\malda\OneDrive\Documents\Projects\PFE1"
DATA_DIR = os.path.join(PROJ_DIR, "data")
SCRIPTS_DIR = os.path.join(PROJ_DIR, "scripts")
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(SCRIPTS_DIR, exist_ok=True)

CSV_OUTPUT = os.path.join(DATA_DIR, "casablanca_places.csv")
JSON_OUTPUT = os.path.join(DATA_DIR, "casablanca_places.json")
REPORT_OUTPUT = os.path.join(DATA_DIR, "cleaning_report.txt")
ROOT_CSV_OUTPUT = os.path.join(PROJ_DIR, "casablanca_places.csv")
ROOT_JSON_OUTPUT = os.path.join(PROJ_DIR, "casablanca_places.json")
ROOT_REPORT_OUTPUT = os.path.join(PROJ_DIR, "cleaning_report.txt")

# 13 Real Casablanca Neighbourhoods with Centroid Coordinates
ZONES = {
    "Maarif": (33.5835, -7.6338),
    "Gauthier": (33.5890, -7.6260),
    "Racine": (33.5910, -7.6420),
    "Anfa/Corniche": (33.5980, -7.6560),
    "Ain Diab": (33.5850, -7.6880),
    "Old Medina": (33.6015, -7.6185),
    "Habous": (33.5786, -7.6067),
    "Californie": (33.5350, -7.6250),
    "Sidi Maarouf": (33.5250, -7.6450),
    "Ain Sebaa": (33.6050, -7.5350),
    "Hay Hassani": (33.5600, -7.6800),
    "Bouskoura": (33.4550, -7.6500),
    "Casa Port/Centre": (33.5985, -7.6120)
}

TARGET_CATEGORIES = [
    "restaurant", "cafe", "fast_food", "bar", "nightclub",
    "museum", "attraction", "accommodation", "park", "beach",
    "shopping", "entertainment"
]

PRICE_ESTIMATES = {
    "cafe": (15, 45),
    "restaurant": (60, 250),
    "fast_food": (30, 80),
    "bar": (70, 200),
    "nightclub": (150, 400),
    "museum": (20, 70),
    "attraction": (0, 100),
    "accommodation": (300, 1500),
    "park": (0, 20),
    "beach": (0, 50),
    "shopping": (50, 500),
    "entertainment": (40, 180)
}

STOPWORDS = {
    "le", "la", "les", "l", "un", "une", "des", "du", "de", "d", "au", "aux",
    "restaurant", "cafe", "café", "hotel", "hôtel", "snack", "fast", "food",
    "bar", "patisserie", "pâtisserie", "boulangerie", "salon", "the", "thé",
    "espace", "chez", "residence", "résidence", "palais", "riad", "center",
    "centre", "club", "store", "boutique", "mall", "market", "dar"
}

# -----------------------------------------------------------------------------
# HELPER FUNCTIONS
# -----------------------------------------------------------------------------
def haversine_m(lat1, lon1, lat2, lon2):
    R = 6371000.0  # Earth radius in meters
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2.0)**2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2.0)**2
    c = 2.0 * math.atan2(math.sqrt(a), math.sqrt(1.0 - a))
    return R * c

def assign_nearest_zone(lat, lon):
    best_zone = "Casa Port/Centre"
    min_dist = float("inf")
    for zone, (z_lat, z_lon) in ZONES.items():
        d = haversine_m(lat, lon, z_lat, z_lon)
        if d < min_dist:
            min_dist = d
            best_zone = zone
    return best_zone

def normalize_phone(phone_str):
    if not phone_str or not isinstance(phone_str, str):
        return None
    # Strip spaces, dashes, dots, parentheses, slashes
    cleaned = re.sub(r"[\s\-\.\(\)\/]", "", phone_str)
    # Check Moroccan formats
    # +212 XXXXXXXXX (9 digits after country code)
    if cleaned.startswith("+212"):
        digits = cleaned[4:]
        if len(digits) == 9 and digits.isdigit():
            return "+212" + digits
    elif cleaned.startswith("00212"):
        digits = cleaned[5:]
        if len(digits) == 9 and digits.isdigit():
            return "+212" + digits
    elif cleaned.startswith("212") and len(cleaned) == 12:
        digits = cleaned[3:]
        if len(digits) == 9 and digits.isdigit():
            return "+212" + digits
    elif cleaned.startswith("0") and len(cleaned) == 10:
        digits = cleaned[1:]
        if len(digits) == 9 and digits.isdigit():
            return "+212" + digits
    # If phone has multiple numbers separated by semicolon/comma
    if ";" in phone_str or "," in phone_str:
        sub = re.split(r"[;,]", phone_str)[0].strip()
        return normalize_phone(sub)
    return None

def normalize_url(url_str):
    if not url_str or not isinstance(url_str, str):
        return None
    u = url_str.strip()
    if not u or u.lower() in ["none", "null", "http://", "https://"]:
        return None
    if not (u.startswith("http://") or u.startswith("https://")):
        u = "https://" + u
    # Strip trailing slashes
    u = re.sub(r"/+$", "", u)
    if "." not in u:
        return None
    return u

def clean_for_matching(text):
    if not text:
        return ""
    # NFKD normalize to strip accents
    s = unicodedata.normalize("NFKD", text)
    s = "".join(c for c in s if not unicodedata.combining(c))
    s = s.lower()
    s = re.sub(r"[^\w\s]", " ", s)
    tokens = [t for t in s.split() if t and t not in STOPWORDS and len(t) > 1]
    return " ".join(tokens)

def name_similarity(n1, n2):
    c1 = clean_for_matching(n1)
    c2 = clean_for_matching(n2)
    if not c1 or not c2:
        return 0.0
    if c1 == c2:
        return 1.0
    return difflib.SequenceMatcher(None, c1, c2).ratio()

def has_arabic(text):
    if not text:
        return False
    return any("\u0600" <= c <= "\u06FF" for c in text)

# -----------------------------------------------------------------------------
# CATEGORY MAPPING LOGIC
# -----------------------------------------------------------------------------
def map_osm_category(tags):
    amenity = tags.get("amenity", "")
    tourism = tags.get("tourism", "")
    leisure = tags.get("leisure", "")
    historic = tags.get("historic", "")
    natural_tag = tags.get("natural", "")
    shop = tags.get("shop", "")

    if amenity in ["restaurant", "food_court"]:
        return "restaurant", amenity
    if amenity in ["cafe", "tea_house", "ice_cream"]:
        return "cafe", amenity
    if amenity in ["fast_food"]:
        return "fast_food", amenity
    if amenity in ["bar", "pub", "lounge"]:
        return "bar", amenity
    if amenity in ["nightclub"]:
        return "nightclub", amenity
    if tourism in ["museum", "gallery"] or amenity in ["arts_centre"]:
        return "museum", tourism or amenity
    if tourism in ["hotel", "motel", "guest_house", "hostel", "apartment"]:
        return "accommodation", tourism
    if tourism in ["attraction", "artwork", "viewpoint", "theme_park", "zoo", "aquarium"] or historic:
        sub = tourism or f"historic_{historic}"
        return "attraction", sub
    if leisure in ["park", "garden", "nature_reserve"]:
        return "park", leisure
    if natural_tag == "beach" or leisure in ["beach_resort"]:
        return "beach", natural_tag or leisure
    if shop in ["mall", "department_store"] or amenity == "marketplace":
        return "shopping", shop or amenity
    if amenity in ["cinema", "theatre"] or leisure in ["water_park", "bowling_alley", "ice_rink"]:
        return "entertainment", amenity or leisure

    return None, None

def map_overture_category(basic_cat, taxonomy):
    primary = ""
    hierarchy = []
    if isinstance(taxonomy, dict):
        primary = taxonomy.get("primary", "") or ""
        hierarchy = taxonomy.get("hierarchy", []) or []

    combined_str = f"{basic_cat} {primary} {' '.join(hierarchy)}".lower()

    # Priority 1: fast_food
    if "fast_food" in combined_str or primary in ["sandwich_shop", "burger_joint", "snack_bar"]:
        return "fast_food", primary or basic_cat

    # Priority 2: cafe
    if any(k in combined_str for k in ["coffee_shop", "tea_house", "ice_cream", "pastry_shop", "bakery_and_cafe"]) or primary == "cafe" or basic_cat == "cafe":
        return "cafe", primary or basic_cat

    # Priority 3: bar & nightclub
    if "nightclub" in combined_str or "dance_club" in combined_str or "disco" in combined_str:
        return "nightclub", primary or basic_cat
    if "bar" in combined_str or "pub" in combined_str or "cocktail_bar" in combined_str or "wine_bar" in combined_str or "lounge" in combined_str:
        return "bar", primary or basic_cat

    # Priority 4: restaurant
    if "restaurant" in combined_str or basic_cat == "restaurant":
        return "restaurant", primary or basic_cat

    # Priority 5: museum
    if "museum" in combined_str or "art_gallery" in combined_str:
        return "museum", primary or basic_cat

    # Priority 6: beach
    if "beach" in combined_str:
        return "beach", primary or basic_cat

    # Priority 7: park
    if "park" in combined_str or "garden" in combined_str or "nature_reserve" in combined_str:
        # Avoid parking or amusement park
        if "parking" not in combined_str and "trailer" not in combined_str:
            return "park", primary or basic_cat

    # Priority 8: accommodation
    if any(k in combined_str for k in ["hotel", "motel", "hostel", "lodging", "resort", "guest_house", "bed_and_breakfast"]):
        return "accommodation", primary or basic_cat

    # Priority 9: attraction
    if any(k in combined_str for k in ["historic_site", "monument", "landmark", "attraction", "scenic_viewpoint", "zoo", "aquarium"]):
        return "attraction", primary or basic_cat

    # Priority 10: shopping
    if any(k in combined_str for k in ["shopping_center", "mall", "outlet_mall", "department_store"]):
        return "shopping", primary or basic_cat

    # Priority 11: entertainment
    if any(k in combined_str for k in ["movie_theater", "cinema", "theater", "performing_arts_venue", "concert_hall", "bowling_alley", "water_park", "arcade", "casino"]):
        return "entertainment", primary or basic_cat

    return None, None

# -----------------------------------------------------------------------------
# MAIN EXTRACTION & CLEANING PIPELINE
# -----------------------------------------------------------------------------
def run_pipeline():
    print("=== STARTING CASABLANCA DATA ENGINEERING PIPELINE ===")

    stats = {
        "raw_osm_count": 0,
        "raw_overture_count": 0,
        "osm_dropped_no_name": 0,
        "osm_dropped_bbox": 0,
        "osm_dropped_category": 0,
        "osm_valid": 0,
        "overture_dropped_no_name": 0,
        "overture_dropped_bbox": 0,
        "overture_dropped_confidence": 0,
        "overture_dropped_category": 0,
        "overture_valid": 0,
        "pre_dedup_total": 0,
        "duplicates_merged": 0,
        "final_count": 0,
    }

    raw_candidates = []

    # -------------------------------------------------------------------------
    # SOURCE 1: OpenStreetMap (Overpass API)
    # -------------------------------------------------------------------------
    raw_osm_file = os.path.join(r"C:\Users\malda\.gemini\antigravity\brain\2d66cbe6-ac97-409c-a0bc-0d83fbc06ae3\scratch", "raw_osm.json")
    if os.path.exists(raw_osm_file):
        print(f"Loading cached OSM data from {raw_osm_file}...")
        with open(raw_osm_file, "r", encoding="utf-8") as f:
            osm_data = json.load(f)
    else:
        print("Fetching fresh OSM data via Overpass API...")
        bbox = f"{BBOX_SOUTH},{BBOX_WEST},{BBOX_NORTH},{BBOX_EAST}"
        query = f"""
        [out:json][timeout:90];
        (
          node["amenity"~"restaurant|cafe|fast_food|bar|pub|nightclub|cinema|theatre"]({bbox});
          way["amenity"~"restaurant|cafe|fast_food|bar|pub|nightclub|cinema|theatre"]({bbox});
          node["tourism"~"museum|attraction|gallery|artwork|hotel|motel|guest_house|hostel|theme_park|zoo|aquarium|viewpoint"]({bbox});
          way["tourism"~"museum|attraction|gallery|artwork|hotel|motel|guest_house|hostel|theme_park|zoo|aquarium|viewpoint"]({bbox});
          node["historic"]({bbox});
          way["historic"]({bbox});
          node["leisure"~"park|garden|beach_resort|water_park"]({bbox});
          way["leisure"~"park|garden|beach_resort|water_park"]({bbox});
          node["natural"="beach"]({bbox});
          way["natural"="beach"]({bbox});
          node["shop"="mall"]({bbox});
          way["shop"="mall"]({bbox});
        );
        out center tags;
        """
        osm_data = {"elements": []}
        mirrors = [
            "https://maps.mail.ru/osm/tools/overpass/api/interpreter",
            "https://overpass-api.de/api/interpreter",
            "https://overpass.kumi.systems/api/interpreter"
        ]
        for mirror in mirrors:
            try:
                r = requests.post(mirror, data={"data": query}, timeout=45)
                if r.status_code == 200:
                    osm_data = r.json()
                    print(f"OSM fetch successful from {mirror}")
                    break
            except Exception as e:
                print(f"Mirror failed ({mirror}): {e}")

    osm_elements = osm_data.get("elements", [])
    stats["raw_osm_count"] = len(osm_elements)
    print(f"Raw OSM elements: {stats['raw_osm_count']}")

    for el in osm_elements:
        tags = el.get("tags", {})
        # Extract name
        name = tags.get("name") or tags.get("name:fr") or tags.get("name:en")
        name_ar = tags.get("name:ar")
        if not name and name_ar:
            name = name_ar

        if not name or not name.strip():
            stats["osm_dropped_no_name"] += 1
            continue

        # Extract coordinates
        lat = el.get("lat") or el.get("center", {}).get("lat")
        lon = el.get("lon") or el.get("center", {}).get("lon")
        if lat is None or lon is None:
            stats["osm_dropped_bbox"] += 1
            continue

        # Bounding box check
        if not (BBOX_SOUTH <= lat <= BBOX_NORTH and BBOX_WEST <= lon <= BBOX_EAST):
            stats["osm_dropped_bbox"] += 1
            continue

        # Category mapping
        cat, subcat = map_osm_category(tags)
        if not cat:
            stats["osm_dropped_category"] += 1
            continue

        osm_id = f"osm:{el.get('type', 'node')}/{el.get('id')}"
        addr_parts = [tags.get("addr:housenumber", ""), tags.get("addr:street", ""), tags.get("addr:suburb", tags.get("addr:district", ""))]
        address = ", ".join(p for p in addr_parts if p).strip() or None

        raw_candidates.append({
            "name": name.strip(),
            "name_ar": name_ar.strip() if name_ar else (name.strip() if has_arabic(name) else None),
            "category": cat,
            "subcategory": subcat or cat,
            "lat": round(lat, 6),
            "lon": round(lon, 6),
            "address": address,
            "phone": normalize_phone(tags.get("phone") or tags.get("contact:phone")),
            "website": normalize_url(tags.get("website") or tags.get("contact:website")),
            "opening_hours": tags.get("opening_hours") or None,
            "fee": tags.get("fee") or tags.get("charge") or None,
            "sources": {"osm"},
            "source_ids": [osm_id]
        })
        stats["osm_valid"] += 1

    print(f"Valid OSM records retained: {stats['osm_valid']}")

    # -------------------------------------------------------------------------
    # SOURCE 2: Overture Maps places theme
    # -------------------------------------------------------------------------
    raw_overture_file = os.path.join(r"C:\Users\malda\.gemini\antigravity\brain\2d66cbe6-ac97-409c-a0bc-0d83fbc06ae3\scratch", "raw_overture.geojson")
    if os.path.exists(raw_overture_file):
        print(f"Reading Overture Maps from {raw_overture_file}...")
        with open(raw_overture_file, "r", encoding="utf-8") as f:
            f.readline() # Header line
            for line in f:
                line = line.rstrip()
                if line.endswith(","): line = line[:-1]
                if line.endswith("]}"): line = line[:-2]
                if not line.startswith("{"): continue
                try:
                    feat = json.loads(line)
                    stats["raw_overture_count"] += 1

                    props = feat.get("properties", {})
                    conf = props.get("confidence", 0.0)
                    if conf is None or conf < 0.5:
                        stats["overture_dropped_confidence"] += 1
                        continue

                    # Names
                    names_obj = props.get("names", {}) or {}
                    name_primary = names_obj.get("primary")
                    name_common = names_obj.get("common")
                    name = name_primary or name_common
                    if not name or not name.strip():
                        stats["overture_dropped_no_name"] += 1
                        continue

                    # Coordinates
                    geom = feat.get("geometry", {})
                    coords = geom.get("coordinates", [])
                    if len(coords) < 2:
                        stats["overture_dropped_bbox"] += 1
                        continue
                    lon, lat = coords[0], coords[1]
                    if not (BBOX_SOUTH <= lat <= BBOX_NORTH and BBOX_WEST <= lon <= BBOX_EAST):
                        stats["overture_dropped_bbox"] += 1
                        continue

                    # Category
                    basic_cat = props.get("basic_category", "") or ""
                    tax = props.get("taxonomy", {}) or {}
                    cat, subcat = map_overture_category(basic_cat, tax)
                    if not cat:
                        stats["overture_dropped_category"] += 1
                        continue

                    # Phone & Website
                    phones = props.get("phones", []) or []
                    norm_phone = normalize_phone(phones[0]) if phones else None

                    websites = props.get("websites", []) or []
                    norm_web = normalize_url(websites[0]) if websites else None

                    # Address
                    addrs = props.get("addresses", []) or []
                    addr_str = None
                    if addrs and isinstance(addrs[0], dict):
                        a = addrs[0]
                        addr_parts = [a.get("freeform"), a.get("locality"), a.get("postcode")]
                        addr_str = ", ".join(str(p) for p in addr_parts if p).strip() or None

                    name_ar = None
                    if has_arabic(name):
                        name_ar = name.strip()

                    ov_id = f"overture:{feat.get('id')}"
                    raw_candidates.append({
                        "name": name.strip(),
                        "name_ar": name_ar,
                        "category": cat,
                        "subcategory": subcat or cat,
                        "lat": round(lat, 6),
                        "lon": round(lon, 6),
                        "address": addr_str,
                        "phone": norm_phone,
                        "website": norm_web,
                        "opening_hours": None,
                        "fee": None,
                        "sources": {"overture"},
                        "source_ids": [ov_id]
                    })
                    stats["overture_valid"] += 1
                except Exception:
                    pass

    print(f"Raw Overture records: {stats['raw_overture_count']}")
    print(f"Valid Overture records (conf >= 0.5 & mapped category): {stats['overture_valid']}")

    stats["pre_dedup_total"] = len(raw_candidates)
    print(f"Total candidate places before deduplication: {stats['pre_dedup_total']}")

    # -------------------------------------------------------------------------
    # DEDUPLICATION ACROSS & WITHIN SOURCES
    # Same category, within ~150 m, name similarity >= 0.82
    # -------------------------------------------------------------------------
    print("Deduplicating places (same category, <= 150m, similarity >= 0.82)...")
    merged_places = []

    # Sort candidates by presence of OSM (prefer OSM names/data) and length of name
    raw_candidates.sort(key=lambda x: ("osm" in x["sources"], len(x.get("address") or "")), reverse=True)

    for cand in raw_candidates:
        match_found = False
        cand_lat = cand["lat"]
        cand_lon = cand["lon"]
        cand_cat = cand["category"]
        cand_name = cand["name"]

        for existing in merged_places:
            if existing["category"] != cand_cat:
                continue

            dist = haversine_m(cand_lat, cand_lon, existing["lat"], existing["lon"])
            if dist > 150.0:
                continue

            sim = name_similarity(cand_name, existing["name"])
            if sim >= 0.82:
                # Merge duplicate
                match_found = True
                stats["duplicates_merged"] += 1
                existing["sources"].update(cand["sources"])
                existing["source_ids"].extend(cand["source_ids"])

                # Keep best name (Latin preferred for primary name if existing is Arabic and cand has Latin)
                if has_arabic(existing["name"]) and not has_arabic(cand_name):
                    existing["name_ar"] = existing["name"]
                    existing["name"] = cand_name
                elif not existing.get("name_ar") and cand.get("name_ar"):
                    existing["name_ar"] = cand["name_ar"]

                # Keep best address (longest non-empty)
                if (not existing["address"]) or (cand["address"] and len(cand["address"]) > len(existing["address"])):
                    existing["address"] = cand["address"]

                # Keep best phone
                if not existing["phone"] and cand["phone"]:
                    existing["phone"] = cand["phone"]

                # Keep best website
                if not existing["website"] and cand["website"]:
                    existing["website"] = cand["website"]

                # Keep best opening hours
                if not existing["opening_hours"] and cand["opening_hours"]:
                    existing["opening_hours"] = cand["opening_hours"]

                # Keep best fee
                if not existing["fee"] and cand["fee"]:
                    existing["fee"] = cand["fee"]

                break

        if not match_found:
            merged_places.append(cand)

    stats["final_count"] = len(merged_places)
    print(f"Duplicates merged: {stats['duplicates_merged']}")
    print(f"Final unique places: {stats['final_count']}")

    # -------------------------------------------------------------------------
    # FINAL ENRICHMENT: ID, ZONE, PRICES
    # -------------------------------------------------------------------------
    final_records = []
    category_counter = Counter()

    for idx, p in enumerate(merged_places, start=1):
        place_id = f"casa_{idx:05d}"
        cat = p["category"]
        category_counter[cat] += 1

        zone = assign_nearest_zone(p["lat"], p["lon"])
        p_min, p_max = PRICE_ESTIMATES.get(cat, (20, 100))

        sources_sorted = sorted(list(p["sources"]))
        source_ids_sorted = sorted(p["source_ids"])

        record = {
            "id": place_id,
            "name": p["name"],
            "name_ar": p.get("name_ar") or None,
            "category": cat,
            "subcategory": p.get("subcategory") or cat,
            "zone": zone,
            "lat": p["lat"],
            "lon": p["lon"],
            "address": p.get("address") or None,
            "phone": p.get("phone") or None,
            "website": p.get("website") or None,
            "opening_hours": p.get("opening_hours") or None,
            "fee": p.get("fee") or None,
            "price_min_mad_est": p_min,
            "price_max_mad_est": p_max,
            "price_is_estimated": True,
            "sources": ",".join(sources_sorted),
            "source_ids": ",".join(source_ids_sorted)
        }
        final_records.append(record)

    # -------------------------------------------------------------------------
    # WRITE DELIVERABLE 1: CSV (UTF-8 with BOM) and JSON
    # -------------------------------------------------------------------------
    columns = [
        "id", "name", "name_ar", "category", "subcategory", "zone",
        "lat", "lon", "address", "phone", "website", "opening_hours",
        "fee", "price_min_mad_est", "price_max_mad_est", "price_is_estimated",
        "sources", "source_ids"
    ]

    for csv_path in [CSV_OUTPUT, ROOT_CSV_OUTPUT]:
        with open(csv_path, "w", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=columns)
            writer.writeheader()
            for r in final_records:
                writer.writerow(r)
        print(f"Saved CSV to {csv_path}")

    for json_path in [JSON_OUTPUT, ROOT_JSON_OUTPUT]:
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(final_records, f, ensure_ascii=False, indent=2)
        print(f"Saved JSON to {json_path}")

    # Also keep pois_casablanca.json for backward compatibility with the frontend/backend
    pois_compat_path = os.path.join(DATA_DIR, "pois_casablanca.json")
    with open(pois_compat_path, "w", encoding="utf-8") as f:
        json.dump(final_records, f, ensure_ascii=False, indent=2)

    # -------------------------------------------------------------------------
    # WRITE DELIVERABLE 3: cleaning_report.txt
    # -------------------------------------------------------------------------
    col_missing = Counter()
    for r in final_records:
        for col in columns:
            if r.get(col) is None or r.get(col) == "":
                col_missing[col] += 1

    report_lines = [
        "=" * 70,
        "CASABLANCA PLACES DATASET — CLEANING & MERGING REPORT",
        "=" * 70,
        "",
        "1. RAW RECORDS PER SOURCE",
        f"  - OpenStreetMap (Overpass API): {stats['raw_osm_count']} raw elements",
        f"  - Overture Maps (places theme):  {stats['raw_overture_count']} raw places",
        f"  - Foursquare Open Source:        0 (skipped; multi-GB global partition exceeds target)",
        "",
        "2. REMOVALS PER CLEANING RULE",
        "  [OpenStreetMap]",
        f"    * Dropped (no name):                {stats['osm_dropped_no_name']}",
        f"    * Dropped (no coord / out of bbox): {stats['osm_dropped_bbox']}",
        f"    * Dropped (outside 12 categories):  {stats['osm_dropped_category']}",
        f"    * Retained valid OSM places:        {stats['osm_valid']}",
        "",
        "  [Overture Maps]",
        f"    * Dropped (confidence < 0.5):       {stats['overture_dropped_confidence']}",
        f"    * Dropped (no name):                {stats['overture_dropped_no_name']}",
        f"    * Dropped (no coord / out of bbox): {stats['overture_dropped_bbox']}",
        f"    * Dropped (outside 12 categories):  {stats['overture_dropped_category']}",
        f"    * Retained valid Overture places:   {stats['overture_valid']}",
        "",
        "3. DEDUPLICATION (Thresholds: same category, distance <= 150m, name similarity >= 0.82)",
        f"  - Total candidate places:             {stats['pre_dedup_total']}",
        f"  - Duplicate records merged:           {stats['duplicates_merged']}",
        f"  - Final unique places in dataset:     {stats['final_count']}",
        "",
        "4. FINAL COUNTS PER CATEGORY (12 target categories)",
    ]

    for cat in TARGET_CATEGORIES:
        cnt = category_counter[cat]
        pct = (cnt / stats['final_count'] * 100.0) if stats['final_count'] else 0
        report_lines.append(f"  - {cat:<16}: {cnt:>5} places ({pct:>5.1f}%)")

    report_lines.extend([
        "",
        "5. DISTRIBUTION PER NEIGHBOURHOOD (ZONE)",
    ])
    zone_counter = Counter(r["zone"] for r in final_records)
    for zone, cnt in zone_counter.most_common():
        pct = (cnt / stats['final_count'] * 100.0) if stats['final_count'] else 0
        report_lines.append(f"  - {zone:<18}: {cnt:>5} places ({pct:>5.1f}%)")

    report_lines.extend([
        "",
        "6. MISSING VALUE ANALYSIS (% MISSING PER COLUMN)",
    ])
    for col in columns:
        miss = col_missing[col]
        pct = (miss / stats['final_count'] * 100.0) if stats['final_count'] else 0
        report_lines.append(f"  - {col:<20}: {miss:>5} missing ({pct:>5.1f}%)")

    report_lines.extend([
        "",
        "7. SOURCES CONTRIBUTION BREAKDOWN",
    ])
    src_counter = Counter(r["sources"] for r in final_records)
    for src, cnt in src_counter.most_common():
        pct = (cnt / stats['final_count'] * 100.0) if stats['final_count'] else 0
        report_lines.append(f"  - Contributed by [{src}]: {cnt:>5} places ({pct:>5.1f}%)")

    report_text = "\n".join(report_lines)
    for rep_path in [REPORT_OUTPUT, ROOT_REPORT_OUTPUT]:
        with open(rep_path, "w", encoding="utf-8") as f:
            f.write(report_text)
        print(f"Saved cleaning report to {rep_path}")

    # -------------------------------------------------------------------------
    # WRITE DELIVERABLE 4: README
    # -------------------------------------------------------------------------
    readme_content = f"""# Casablanca Places Dataset — CasaTrip

A cleaned, merged, real-world dataset of places in Greater Casablanca, Morocco, built for the **CasaTrip** tourism application.

## Bounding Box
- South: {BBOX_SOUTH}
- West: {BBOX_WEST}
- North: {BBOX_NORTH}
- East: {BBOX_EAST}

## Deliverables
- `casablanca_places.csv`: UTF-8 with BOM, tabular dataset.
- `casablanca_places.json`: Complete JSON dataset.
- `scripts/build_casablanca_dataset.py`: Reproducible Python data pipeline script.
- `cleaning_report.txt`: Record counts at each cleaning and merging step.

## Sources & Licenses
1. **OpenStreetMap (OSM)**:
   - Extracted via Overpass API with `out center tags;`.
   - License: **Open Data Commons Open Database License (ODbL)**.
   - © OpenStreetMap contributors.
2. **Overture Maps Foundation (Places Theme)**:
   - Extracted via `overturemaps` CLI with bounding box filter and confidence $\\ge 0.5$.
   - License: **Community Data License Agreement – Permissive (CDLA-Permissive v2.0)**.
   - Attribution: Overture Maps Foundation contributors.

## 12 Target Categories
`restaurant`, `cafe`, `fast_food`, `bar`, `nightclub`, `museum`, `attraction`, `accommodation`, `park`, `beach`, `shopping`, `entertainment`.

## Deduplication Method
Places across and within sources are merged when:
1. They share the same target category.
2. Distance $\\le 150$ meters (Haversine formula).
3. Name similarity $\\ge 0.82$ (accent-stripped, lowercased, common place stopwords removed, Levenshtein/difflib ratio).

## Price Ranges
Real prices are not published by OSM or Overture Maps. Estimated MAD price ranges are provided as category placeholders, flagged with `price_is_estimated = True`. They are estimations and should not be presented as measured data.

## 13 Neighbourhood Zones
Places are assigned to the nearest neighbourhood centroid:
Maarif, Gauthier, Racine, Anfa/Corniche, Ain Diab, Old Medina, Habous, Californie, Sidi Maarouf, Ain Sebaa, Hay Hassani, Bouskoura, Casa Port/Centre.

## Summary of Dataset
- Total unique places: **{stats['final_count']}**
- OSM elements processed: **{stats['raw_osm_count']}**
- Overture places processed: **{stats['raw_overture_count']}**
- Duplicate pairs merged: **{stats['duplicates_merged']}**
"""
    readme_path = os.path.join(PROJ_DIR, "README_DATASET.md")
    with open(readme_path, "w", encoding="utf-8") as f:
        f.write(readme_content)
    print(f"Saved dataset README to {readme_path}")

    # Output top 10 rows and category counts to console
    print("\n" + "=" * 60)
    print("CATEGORY COUNTS (12 Target Categories):")
    print("=" * 60)
    for cat, cnt in category_counter.most_common():
        print(f"  {cat:<16}: {cnt:>5} places")

    print("\n" + "=" * 60)
    print("FIRST 10 ROWS OF casablanca_places.csv:")
    print("=" * 60)
    for r in final_records[:10]:
        print(f"[{r['id']}] {r['name']} ({r['category']}) - Zone: {r['zone']} - Lat/Lon: ({r['lat']}, {r['lon']}) - Sources: {r['sources']}")
    print("=" * 60)

if __name__ == "__main__":
    run_pipeline()
